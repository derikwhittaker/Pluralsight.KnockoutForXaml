///�<reference�path="../Scripts/typings/jquery/jquery.d.ts"�/>
///�<reference�path="../Scripts/typings/knockout.mapping/knockout.mapping.d.ts"�/>
///�<reference�path="../Scripts/typings/knockout/knockout.d.ts"�/>
 
module k4xaml {
    export class MainViewModel {
   
    }
}
